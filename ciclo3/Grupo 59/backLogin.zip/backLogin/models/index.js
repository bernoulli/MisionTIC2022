const Usuario = require('./usuario');
const Categoria = require('./categoria');
const Articulo = require('./articulo');

module.exports = {
    Usuario,
    Categoria,
    Articulo
}